"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// asset-input/lib/xml-writer-stack.function.ts
var xml_writer_stack_function_exports = {};
__export(xml_writer_stack_function_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(xml_writer_stack_function_exports);
var import_aws_sdk = require("aws-sdk");
var CONVERT = __toESM(require("xml-js"));
var s3 = new import_aws_sdk.S3();
var handler = async (event, context) => {
  console.log(`Event: ${JSON.stringify(event, null, 2)}`);
  console.log(`Context: ${JSON.stringify(context, null, 2)}`);
  const record = event.Records[0];
  const key = record.s3.object.key;
  const bucket = record.s3.bucket.name;
  console.log(`Bucket: ${record.s3.bucket.name}, Key: ${key}`);
  const data = await s3.getObject({
    Bucket: bucket,
    Key: key
  }).promise();
  const TARGET_BUCKET_NAME = process.env.TARGET_BUCKET_NAME || "";
  const TARGET_PREFIX = process.env.TARGET_PREFIX || "xml/";
  const fileContent = data.Body?.toString() || "";
  const textWithCommas = fileContent.replace(/(\r?\n)/g, ",$1");
  const template = `{"Aktive_Kunden": {"kunde": [${textWithCommas}]}}`;
  var test = CONVERT.json2xml(template, { compact: true, spaces: 4 });
  const xmlContent = CONVERT.json2xml(template, { compact: true, ignoreComment: true, spaces: 4 });
  const filename = key.split("/").pop() || "";
  const targetKey = TARGET_PREFIX + filename.replace(".json", ".xml");
  console.log(`Target Bucket: ${TARGET_BUCKET_NAME}, Key: ${targetKey}`);
  await s3.putObject({
    Bucket: TARGET_BUCKET_NAME,
    Key: targetKey,
    Body: xmlContent,
    ContentType: "text/xml"
  }).promise();
  return {
    statusCode: 200,
    body: "result"
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
